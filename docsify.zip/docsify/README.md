# Menambahkan Rumus

> Ini merupakan catatan penting
> Misalnya $f(x)=2x$

$$
\begin{equation}
\begin{split}   a &=b+c\\
      &=e+f
\end{split}
\end{equation}
$$


