# Media Pembelajaran Lingkaran

<img src="./guitar.png" width=400px></img>

Dirancang: I Made Dwipayana

