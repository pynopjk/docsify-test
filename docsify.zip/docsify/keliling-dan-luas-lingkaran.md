# Contoh Quiz Menggunakan Google Form

<div class="container">
    <iframe class="responsive-iframe" style="border: 0" src="https://docs.google.com/forms/d/e/1FAIpQLScqhAS18a1ABP8yz_RdqGf80ENTGzhvEq4JxVsBYptmRfZVgA/viewform?embedded=true" width="640" height="2000" frameBorder="0" marginheight="0" marginwidth="0">Memuat…</iframe>
</div>

# tes
# dfhkas
# dfkjk
